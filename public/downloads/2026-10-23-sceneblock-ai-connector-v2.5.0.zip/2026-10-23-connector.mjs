import http from 'node:http';
import {randomBytes,randomInt,timingSafeEqual} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {createProviders} from './2026-10-23-providers.mjs';
export function allowedOrigin(origin){try{const u=new URL(origin);if(u.origin!==origin)return false;return origin==='https://scene-block.vercel.app'||u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)&&['4173','4174','5173','5174','8767'].includes(u.port)}catch{return false}}
const safeEqual=(a,b)=>{if(typeof a!=='string'||typeof b!=='string')return false;const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y)};
export function createConnector({providers=createProviders(),code=String(randomInt(100000,1000000)),port=8766}={}){
 let token=null,busy=false,failures=0,windowStart=Date.now();
 const server=http.createServer(async(req,res)=>{
 const origin=req.headers.origin,host=req.headers.host;
 const reply=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...(allowedOrigin(origin)?{'Access-Control-Allow-Origin':origin,'Vary':'Origin'}:{})});res.end(JSON.stringify(data))};
 if(host!==`127.0.0.1:${port}`&&host!==`localhost:${port}`)return reply(403,{error:'허용되지 않은 Host입니다.'});
 if(!allowedOrigin(origin))return reply(403,{error:'허용되지 않은 사이트입니다. 공식 SceneBlock에서 연결하세요.'});
 if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':origin,'Vary':'Origin','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600',...(req.headers['access-control-request-private-network']==='true'?{'Access-Control-Allow-Private-Network':'true'}:{})});return res.end()}
 if(req.method==='GET'&&req.url==='/health')return reply(200,{service:'sceneblock-ai',version:'2.5.0'});
 try{
 if(req.method==='POST'&&req.url==='/pair'){
 if(Date.now()-windowStart>60000){windowStart=Date.now();failures=0}if(failures>=5)return reply(429,{error:'연결 시도가 많습니다. 1분 뒤 다시 시도하세요.'});const body=await readJSON(req);if(!safeEqual(body.code,code)){failures++;return reply(401,{error:'연결 코드가 일치하지 않습니다.'})}token=randomBytes(32).toString('hex');failures=0;return reply(200,{token})}
 if(!token||!safeEqual(req.headers.authorization,`Bearer ${token}`))return reply(401,{error:'연결 코드를 입력해 먼저 연결하세요.'});
 if(req.method==='GET'&&req.url==='/status')return reply(200,{providers:await providers.status()});
 if(req.method==='POST'&&req.url==='/generate'){
 if(busy)return reply(409,{error:'AI가 장면을 구성 중입니다. 완료 후 다시 요청하세요.'});const body=await readJSON(req);if(!['codex','claude'].includes(body.provider)||typeof body.prompt!=='string'||!body.prompt.trim()||body.prompt.length>12000||body.context!==undefined&&JSON.stringify(body.context).length>8000)return reply(400,{error:'AI 종류 또는 장면 설명을 확인하세요. 설명은 최대 12,000자입니다.'});if(busy)return reply(409,{error:'AI가 장면을 구성 중입니다. 완료 후 다시 요청하세요.'});busy=true;const controller=new AbortController(),cancel=()=>{if(!res.writableEnded)controller.abort()};res.on('close',cancel);try{const plan=await providers.generate({...body,signal:controller.signal});return reply(200,{plan})}finally{busy=false;res.removeListener('close',cancel)}}
 return reply(404,{error:'지원하지 않는 요청입니다.'});
 }catch(error){return reply(error.status??500,{error:error.status?error.message:'AI 요청을 완료하지 못했습니다. 연결 프로그램과 공식 CLI의 로그인·사용 한도를 확인하세요.'})}
 });server.requestTimeout=15000;server.headersTimeout=10000;return {server,code};
}
async function readJSON(req){if(!String(req.headers['content-type']??'').startsWith('application/json'))throw Object.assign(Error('JSON 요청이 필요합니다.'),{status:415});let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>32768)throw Object.assign(Error('요청이 너무 큽니다.'),{status:413});chunks.push(chunk)}try{return JSON.parse(Buffer.concat(chunks))}catch{throw Object.assign(Error('JSON 형식이 잘못되었습니다.'),{status:400})}}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){if(Number(process.versions.node.split('.')[0])<22){console.error('Node.js 22 이상이 필요합니다.');process.exit(1)}const {server,code}=createConnector();server.on('error',error=>{console.error(error.code==='EADDRINUSE'?'이미 연결 프로그램이 실행 중이거나 8766 포트를 사용 중입니다.':'연결 프로그램을 시작하지 못했습니다.');process.exitCode=1});server.listen(8766,'127.0.0.1',()=>{console.log(`SceneBlock AI 연결 프로그램 v2.5.0\n공식 사이트: https://scene-block.vercel.app\n연결 코드: ${code}\n이 창을 켜둔 상태로 사이트의 AI 연결에 코드를 입력하세요.\n설치·로그인은 자동 실행하지 않습니다. 종료: Ctrl+C`)});for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>process.exit(0)))}
